var searchData=
[
  ['begin',['begin',['../classCircularBuffer.html#a792545be538920a0efbeea005279831b',1,'CircularBuffer::begin()'],['../classEEPROM__ItemListClass.html#ab6e479bea61df079b1711a0d5d015489',1,'EEPROM_ItemListClass::begin()']]]
];
